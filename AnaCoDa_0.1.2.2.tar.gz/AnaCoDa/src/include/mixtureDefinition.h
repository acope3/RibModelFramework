
// This is a mapping of delta category to mixture definition.
class mixtureDefinition
{
public:
	unsigned delM; // With PA(NSE) model, this refers to alpha
	unsigned delEta; // With PA(NSE) model, this refers to lambda prime
};
